"use client";

import { useState, useEffect } from "react";
import AnimeCard from "@/components/AnimeCard";

interface Anime {
  id: number;
  title: string;
  slug: string;
  imageUrl: string;
  episodes: number;
  status: string;
  rating: number;
  year: number;
  type: string;
  studio: string;
}

export default function AnimePage() {
  const [animeList, setAnimeList] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [status, setStatus] = useState("");
  const [genre, setGenre] = useState("");

  const genres = [
    "action", "adventure", "comedy", "drama", "fantasy",
    "horror", "mystery", "romance", "sci-fi", "slice-of-life",
    "sports", "supernatural", "thriller", "mecha", "shounen", "isekai",
  ];

  useEffect(() => {
    const fetchAnime = async () => {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (sort) params.set("sort", sort);
      if (status) params.set("status", status);
      if (genre) params.set("genre", genre);

      try {
        const res = await fetch(`/api/anime?${params.toString()}`);
        const data = await res.json();
        setAnimeList(data);
      } catch (err) {
        console.error("Failed to fetch anime:", err);
      } finally {
        setLoading(false);
      }
    };

    const timeout = setTimeout(fetchAnime, 300);
    return () => clearTimeout(timeout);
  }, [search, sort, status, genre]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
          <span className="gradient-text">Anime</span> Collection
        </h1>
        <p className="text-slate-400">Browse through our collection of anime series</p>
      </div>

      {/* Filters */}
      <div className="bg-[#1a1a2e] border border-white/5 rounded-xl p-4 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="md:col-span-2">
            <div className="relative">
              <svg
                className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search anime..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#0f0f1a] border border-white/10 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
              />
            </div>
          </div>

          {/* Sort */}
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="px-4 py-2.5 bg-[#0f0f1a] border border-white/10 rounded-lg text-white focus:outline-none focus:border-purple-500 transition-colors"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="rating">Top Rated</option>
          </select>

          {/* Status */}
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="px-4 py-2.5 bg-[#0f0f1a] border border-white/10 rounded-lg text-white focus:outline-none focus:border-purple-500 transition-colors"
          >
            <option value="">All Status</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        {/* Genre chips */}
        <div className="flex flex-wrap gap-2 mt-4">
          <button
            onClick={() => setGenre("")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              genre === ""
                ? "bg-purple-500 text-white"
                : "bg-white/5 text-slate-400 hover:bg-white/10"
            }`}
          >
            All
          </button>
          {genres.map((g) => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
                genre === g
                  ? "bg-purple-500 text-white"
                  : "bg-white/5 text-slate-400 hover:bg-white/10"
              }`}
            >
              {g.replace("-", " ")}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-[#1a1a2e] rounded-xl overflow-hidden animate-pulse">
              <div className="aspect-[3/4] bg-white/5" />
              <div className="p-3">
                <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
                <div className="h-3 bg-white/5 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : animeList.length === 0 ? (
        <div className="text-center py-20">
          <span className="text-6xl mb-4 block">🔍</span>
          <h3 className="text-xl font-semibold text-white mb-2">No anime found</h3>
          <p className="text-slate-400">Try adjusting your filters or search term</p>
        </div>
      ) : (
        <>
          <p className="text-slate-400 text-sm mb-4">Found {animeList.length} anime</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {animeList.map((item) => (
              <AnimeCard
                key={item.id}
                id={item.id}
                title={item.title}
                slug={item.slug}
                imageUrl={item.imageUrl}
                episodes={item.episodes}
                status={item.status}
                rating={item.rating}
                year={item.year}
                type={item.type}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
