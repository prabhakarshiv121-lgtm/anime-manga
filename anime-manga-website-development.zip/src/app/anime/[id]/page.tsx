import { db } from "@/db";
import { anime, genres, animeGenres } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AnimeDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const animeId = parseInt(id);

  if (isNaN(animeId)) {
    notFound();
  }

  const result = await db.select().from(anime).where(eq(anime.id, animeId)).limit(1);

  if (result.length === 0) {
    notFound();
  }

  const animeData = result[0];

  const animeGenreList = await db
    .select({ name: genres.name, slug: genres.slug })
    .from(animeGenres)
    .innerJoin(genres, eq(animeGenres.genreId, genres.id))
    .where(eq(animeGenres.animeId, animeId));

  const relatedAnime = await db
    .select()
    .from(anime)
    .where(eq(anime.type, animeData.type))
    .limit(6);

  return (
    <div>
      {/* Banner */}
      <div className="relative h-[40vh] md:h-[50vh] overflow-hidden">
        <img
          src={animeData.bannerUrl || animeData.imageUrl}
          alt={animeData.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f1a] via-[#0f0f1a]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f0f1a]/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <div className="w-48 md:w-64 mx-auto md:mx-0">
              <img
                src={animeData.imageUrl}
                alt={animeData.title}
                className="w-full rounded-xl shadow-2xl shadow-purple-500/20 border border-white/10"
              />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm text-slate-400 mb-4">
              <Link href="/" className="hover:text-purple-400 transition-colors">Home</Link>
              <span>/</span>
              <Link href="/anime" className="hover:text-purple-400 transition-colors">Anime</Link>
              <span>/</span>
              <span className="text-slate-300">{animeData.title}</span>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{animeData.title}</h1>

            {/* Badges */}
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <span className={`px-3 py-1 rounded-lg text-sm font-semibold ${
                animeData.status === "Ongoing"
                  ? "bg-green-500/20 text-green-400 border border-green-500/30"
                  : "bg-blue-500/20 text-blue-400 border border-blue-500/30"
              }`}>
                {animeData.status}
              </span>
              <span className="px-3 py-1 rounded-lg text-sm font-semibold bg-purple-500/20 text-purple-400 border border-purple-500/30">
                {animeData.type}
              </span>
              <span className="px-3 py-1 rounded-lg text-sm font-semibold bg-slate-500/20 text-slate-400 border border-slate-500/30">
                {animeData.year}
              </span>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className={`w-5 h-5 ${
                      star <= Math.round(animeData.rating / 2) ? "text-yellow-400" : "text-slate-600"
                    }`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <span className="text-lg font-semibold text-white">{(animeData.rating / 2).toFixed(1)}</span>
              <span className="text-slate-400">/ 5.0</span>
            </div>

            {/* Meta */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Episodes</span>
                <span className="text-white font-semibold">{animeData.episodes}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Studio</span>
                <span className="text-white font-semibold">{animeData.studio}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Status</span>
                <span className="text-white font-semibold">{animeData.status}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Year</span>
                <span className="text-white font-semibold">{animeData.year}</span>
              </div>
            </div>

            {/* Genres */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-slate-400 mb-2">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {animeGenreList.map((g) => (
                  <Link
                    key={g.slug}
                    href={`/anime?genre=${g.slug}`}
                    className="px-3 py-1 rounded-lg text-sm bg-purple-500/10 text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 transition-colors"
                  >
                    {g.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Synopsis</h3>
              <p className="text-slate-300 leading-relaxed">{animeData.description}</p>
            </div>
          </div>
        </div>

        {/* Related Anime */}
        {relatedAnime.length > 1 && (
          <section className="mt-16 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">Related Anime</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {relatedAnime
                .filter((a) => a.id !== animeData.id)
                .slice(0, 5)
                .map((item) => (
                  <Link key={item.id} href={`/anime/${item.id}`} className="block group">
                    <div className="bg-[#1a1a2e] rounded-xl overflow-hidden card-hover border border-white/5">
                      <div className="relative aspect-[3/4] overflow-hidden">
                        <img
                          src={item.imageUrl}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        <div className="absolute bottom-0 left-0 right-0 p-3">
                          <h3 className="text-white font-bold text-sm line-clamp-2">{item.title}</h3>
                          <span className="text-slate-300 text-xs">{item.episodes} EP</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
