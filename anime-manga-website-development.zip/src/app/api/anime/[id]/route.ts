import { NextResponse } from "next/server";
import { db } from "@/db";
import { anime, genres, animeGenres } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const result = await db
      .select()
      .from(anime)
      .where(eq(anime.id, parseInt(id)))
      .limit(1);

    if (result.length === 0) {
      return NextResponse.json({ error: "Anime not found" }, { status: 404 });
    }

    const animeGenresResult = await db
      .select({ name: genres.name, slug: genres.slug })
      .from(animeGenres)
      .innerJoin(genres, eq(animeGenres.genreId, genres.id))
      .where(eq(animeGenres.animeId, parseInt(id)));

    return NextResponse.json({
      ...result[0],
      genres: animeGenresResult,
    });
  } catch (error) {
    console.error("Error fetching anime:", error);
    return NextResponse.json({ error: "Failed to fetch anime" }, { status: 500 });
  }
}
