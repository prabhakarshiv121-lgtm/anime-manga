import { NextResponse } from "next/server";
import { db } from "@/db";
import { anime, genres, animeGenres } from "@/db/schema";
import { eq, like, and, desc, SQL } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const genreSlug = searchParams.get("genre") || "";
    const status = searchParams.get("status") || "";
    const sort = searchParams.get("sort") || "newest";

    const conditions: SQL[] = [];

    if (search) {
      conditions.push(like(anime.title, `%${search}%`));
    }

    if (status) {
      conditions.push(eq(anime.status, status));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const orderClause = sort === "rating"
      ? desc(anime.rating)
      : sort === "oldest"
        ? anime.year
        : desc(anime.year);

    const baseQuery = db.select().from(anime);
    const queryWithWhere = whereClause ? baseQuery.where(whereClause) : baseQuery;
    const results = await queryWithWhere.orderBy(orderClause);

    let filtered = results;
    if (genreSlug) {
      const genreResults = await db
        .select({ animeId: animeGenres.animeId })
        .from(animeGenres)
        .innerJoin(genres, eq(animeGenres.genreId, genres.id))
        .where(eq(genres.slug, genreSlug));

      const genreAnimeIds = new Set(genreResults.map((r) => r.animeId));
      filtered = results.filter((a) => genreAnimeIds.has(a.id));
    }

    return NextResponse.json(filtered);
  } catch (error) {
    console.error("Error fetching anime:", error);
    return NextResponse.json({ error: "Failed to fetch anime" }, { status: 500 });
  }
}
