import { NextResponse } from "next/server";
import { db } from "@/db";
import { genres } from "@/db/schema";

export async function GET() {
  try {
    const allGenres = await db.select().from(genres);
    return NextResponse.json(allGenres);
  } catch (error) {
    console.error("Error fetching genres:", error);
    return NextResponse.json({ error: "Failed to fetch genres" }, { status: 500 });
  }
}
