import { NextResponse } from "next/server";
import { db } from "@/db";
import { manga, genres, mangaGenres } from "@/db/schema";
import { eq, like, and, desc, SQL } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const genreSlug = searchParams.get("genre") || "";
    const status = searchParams.get("status") || "";
    const sort = searchParams.get("sort") || "newest";

    const conditions: SQL[] = [];

    if (search) {
      conditions.push(like(manga.title, `%${search}%`));
    }

    if (status) {
      conditions.push(eq(manga.status, status));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const orderClause = sort === "rating"
      ? desc(manga.rating)
      : sort === "chapters"
        ? desc(manga.chapters)
        : desc(manga.id);

    const baseQuery = db.select().from(manga);
    const queryWithWhere = whereClause ? baseQuery.where(whereClause) : baseQuery;
    const results = await queryWithWhere.orderBy(orderClause);

    let filtered = results;
    if (genreSlug) {
      const genreResults = await db
        .select({ mangaId: mangaGenres.mangaId })
        .from(mangaGenres)
        .innerJoin(genres, eq(mangaGenres.genreId, genres.id))
        .where(eq(genres.slug, genreSlug));

      const genreMangaIds = new Set(genreResults.map((r) => r.mangaId));
      filtered = results.filter((m) => genreMangaIds.has(m.id));
    }

    return NextResponse.json(filtered);
  } catch (error) {
    console.error("Error fetching manga:", error);
    return NextResponse.json({ error: "Failed to fetch manga" }, { status: 500 });
  }
}
