import { NextResponse } from "next/server";
import { db } from "@/db";
import { manga, genres, mangaGenres } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const result = await db
      .select()
      .from(manga)
      .where(eq(manga.id, parseInt(id)))
      .limit(1);

    if (result.length === 0) {
      return NextResponse.json({ error: "Manga not found" }, { status: 404 });
    }

    const mangaGenresResult = await db
      .select({ name: genres.name, slug: genres.slug })
      .from(mangaGenres)
      .innerJoin(genres, eq(mangaGenres.genreId, genres.id))
      .where(eq(mangaGenres.mangaId, parseInt(id)));

    return NextResponse.json({
      ...result[0],
      genres: mangaGenresResult,
    });
  } catch (error) {
    console.error("Error fetching manga:", error);
    return NextResponse.json({ error: "Failed to fetch manga" }, { status: 500 });
  }
}
