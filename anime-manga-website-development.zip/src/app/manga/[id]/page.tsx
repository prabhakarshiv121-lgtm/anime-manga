import { db } from "@/db";
import { manga, genres, mangaGenres } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function MangaDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const mangaId = parseInt(id);

  if (isNaN(mangaId)) {
    notFound();
  }

  const result = await db.select().from(manga).where(eq(manga.id, mangaId)).limit(1);

  if (result.length === 0) {
    notFound();
  }

  const mangaData = result[0];

  const mangaGenreList = await db
    .select({ name: genres.name, slug: genres.slug })
    .from(mangaGenres)
    .innerJoin(genres, eq(mangaGenres.genreId, genres.id))
    .where(eq(mangaGenres.mangaId, mangaId));

  const relatedManga = await db
    .select()
    .from(manga)
    .limit(6);

  return (
    <div>
      {/* Header background */}
      <div className="relative h-[30vh] md:h-[40vh] overflow-hidden">
        <img
          src={mangaData.imageUrl}
          alt={mangaData.title}
          className="w-full h-full object-cover blur-sm scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f1a] via-[#0f0f1a]/70 to-[#0f0f1a]/40" />
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <div className="w-48 md:w-64 mx-auto md:mx-0">
              <img
                src={mangaData.imageUrl}
                alt={mangaData.title}
                className="w-full rounded-xl shadow-2xl shadow-pink-500/20 border border-white/10"
              />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm text-slate-400 mb-4">
              <Link href="/" className="hover:text-pink-400 transition-colors">Home</Link>
              <span>/</span>
              <Link href="/manga" className="hover:text-pink-400 transition-colors">Manga</Link>
              <span>/</span>
              <span className="text-slate-300">{mangaData.title}</span>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{mangaData.title}</h1>

            {/* Badges */}
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <span className={`px-3 py-1 rounded-lg text-sm font-semibold ${
                mangaData.status === "Ongoing"
                  ? "bg-green-500/20 text-green-400 border border-green-500/30"
                  : mangaData.status === "Completed"
                    ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                    : "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
              }`}>
                {mangaData.status}
              </span>
              <span className="px-3 py-1 rounded-lg text-sm font-semibold bg-pink-500/20 text-pink-400 border border-pink-500/30">
                {mangaData.type}
              </span>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className={`w-5 h-5 ${
                      star <= Math.round(mangaData.rating / 2) ? "text-yellow-400" : "text-slate-600"
                    }`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <span className="text-lg font-semibold text-white">{(mangaData.rating / 2).toFixed(1)}</span>
              <span className="text-slate-400">/ 5.0</span>
            </div>

            {/* Meta */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Chapters</span>
                <span className="text-white font-semibold">{mangaData.chapters}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Volumes</span>
                <span className="text-white font-semibold">{mangaData.volumes}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Author</span>
                <span className="text-white font-semibold">{mangaData.author}</span>
              </div>
              <div className="bg-[#1a1a2e] border border-white/5 rounded-lg p-3">
                <span className="text-slate-400 text-xs block">Status</span>
                <span className="text-white font-semibold">{mangaData.status}</span>
              </div>
            </div>

            {/* Genres */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-slate-400 mb-2">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {mangaGenreList.map((g) => (
                  <Link
                    key={g.slug}
                    href={`/manga?genre=${g.slug}`}
                    className="px-3 py-1 rounded-lg text-sm bg-pink-500/10 text-pink-400 border border-pink-500/20 hover:bg-pink-500/20 transition-colors"
                  >
                    {g.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Synopsis</h3>
              <p className="text-slate-300 leading-relaxed">{mangaData.description}</p>
            </div>
          </div>
        </div>

        {/* Related Manga */}
        {relatedManga.length > 1 && (
          <section className="mt-16 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">More Manga</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {relatedManga
                .filter((m) => m.id !== mangaData.id)
                .slice(0, 5)
                .map((item) => (
                  <Link key={item.id} href={`/manga/${item.id}`} className="block group">
                    <div className="bg-[#1a1a2e] rounded-xl overflow-hidden card-hover border border-white/5">
                      <div className="relative aspect-[3/4] overflow-hidden">
                        <img
                          src={item.imageUrl}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        <div className="absolute bottom-0 left-0 right-0 p-3">
                          <h3 className="text-white font-bold text-sm line-clamp-2">{item.title}</h3>
                          <span className="text-slate-300 text-xs">{item.chapters} Ch</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
